<?php
session_start();

// Cek apakah pengguna sudah login sebagai admin
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Iformasi</title>
    <!-- Link Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        /* Tambahkan CSS kustom di sini */
        body {
            font-family: 'Poppins', sans-serif;
        }

        /* Sidebar Full Height */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100vh;
            background-color: #343a40;
            color: white;
            padding: 30px 10px;
        }

        .sidebar h3 {
            text-align: center;
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 30px;
        }

        .sidebar .nav-link {
            color: white;
            font-size: 18px;
            padding: 10px 20px;
            transition: background-color 0.3s;
        }

        .sidebar .nav-link:hover {
            background-color: #007bff;
        }

        .main-content {
            margin-left: 260px;
            padding: 30px;
        }

        .card {
            margin-bottom: 30px;
        }

        footer {
            background-color: #343a40;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Iformasi</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Main content area -->
<div class="container-fluid mt-5 pt-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 sidebar">
            <h3>Panel Admin</h3>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="admin.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="manage_content.php">Manage Content</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="col-md-9 col-lg-10 main-content">
            <h2>Selamat Datang, Admin!</h2>
            <p class="lead">Kelola konten di dashboard ini.</p>

            <!-- Manage Content -->
            <div class="row">
                <div class="col-md-6">
                    <div class="card text-white bg-success mb-3">
                        <div class="card-header">Manage Content</div>
                        <div class="card-body">
                            <h5 class="card-title">Kelola Konten</h5>
                            <p class="card-text">Klik di sini untuk mengelola konten yang diupload oleh pengguna, menambah atau menghapus informasi.</p>
                            <a href="manage_content.php" class="btn btn-light">Manage Content</a>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- End of Main Content -->
    </div> <!-- End of Row -->
</div> <!-- End of Container -->

<!-- Footer -->
<footer>
    <p>&copy; 2024 Iformasi. Semua hak cipta dilindungi.</p>
</footer>

<!-- Bootstrap JS dan Dependencies -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

</body>
</html>
