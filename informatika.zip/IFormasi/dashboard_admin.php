<?php
session_start();

// Debug sesi untuk memastikan sesi admin ada
var_dump($_SESSION); // Gunakan ini untuk debug, hapus setelah pengecekan selesai

if (!isset($_SESSION['admin']) || $_SESSION['admin']['role'] !== 'admin') {
    header('Location: login.php'); // Redirect ke login jika bukan admin
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Iformasi</title>
    <style>
        /* CSS untuk Halaman Admin - dashboard_admin.php */
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }

        /* Header */
        header {
            background-color: #3498db;
            color: white;
            padding: 20px;
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 24px;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #1abc9c;
        }

        .sidebar-header {
            padding: 20px;
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            background-color: #2980b9;
        }

        /* Main Content */
        .main-content {
            margin-left: 270px;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .main-content h2 {
            font-size: 22px;
            color: #3498db;
        }

        .main-content p {
            font-size: 16px;
            color: #666;
        }

        /* Responsivitas */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                position: static;
                height: auto;
            }

            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>

<header>
    <div class="header-container">
        <h1>Dashboard Admin</h1>
    </div>
</header>

<div class="dashboard-container">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h2>Panel Admin</h2>
        </div>
        <nav>
            <ul class="sidebar-menu">
                <li><a href="dashboard_admin.php" class="active">Dashboard</a></li>
                <li><a href="manage_users.php">Kelola Pengguna</a></li>
                <li><a href="manage_info.php">Kelola Informasi</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <header>
            <h2>Selamat Datang, Admin!</h2>
        </header>

        <p>Anda dapat mengelola pengguna, mengelola informasi, atau logout. Pilih menu di sebelah kiri untuk melanjutkan.</p>

        <!-- Optional additional content can go here -->
    </main>
</div>

</body>
</html>
