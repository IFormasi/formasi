<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'user') {
    header('Location: login.php'); // Redirect jika bukan user
    exit;
}

// Membaca data dari informasi.json
$informasiFile = 'informasi.json';
$informasiData = file_exists($informasiFile) ? json_decode(file_get_contents($informasiFile), true) : [];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lihat Informasi - Iformasi</title>
    <link rel="stylesheet" href="assets/css/user.css"> <!-- Link ke CSS -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="header-container">
            <h1>Lihat Informasi</h1>
        </div>
    </header>

    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <nav>
                <ul>
                    <li><a href="dashboard_user.php">Dashboard</a></li>
                    <li><a href="upload_info.php">Upload Informasi</a></li>
                    <li><a href="view_info.php" class="active">Lihat Informasi</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </aside>

        <main class="main-content">
            <h2>Informasi yang Telah Diunggah</h2>
            
            <!-- Menampilkan semua informasi yang ada -->
            <?php if (count($informasiData) > 0): ?>
                <?php foreach ($informasiData as $info): ?>
                    <div class="info-box">
                        <h3><?php echo htmlspecialchars($info['judul']); ?></h3>
                        <p><strong>Dikirim oleh: </strong><?php echo htmlspecialchars($info['user']); ?></p>
                        <p>
                            <?php 
                            // Menggunakan nl2br dan kemudian memproses konten untuk mendeteksi link
                            $konten = nl2br(htmlspecialchars($info['konten']));
                            // Gantilah setiap URL dalam teks menjadi tag <a> untuk link
                            echo preg_replace('/(https?:\/\/[^\s]+)/', '<a href="$1" class="info-link" target="_blank">$1</a>', $konten);
                            ?>
                        </p>

                        <!-- Menampilkan gambar jika ada -->
                        <?php if (!empty($info['image'])): ?>
                            <img src="uploads/<?php echo htmlspecialchars($info['image']); ?>" alt="Gambar Informasi" class="info-image">
                        <?php endif; ?>

                        <p><small><em>Waktu Unggah: <?php echo htmlspecialchars($info['created_at']); ?></em></small></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Tidak ada informasi yang tersedia.</p>
            <?php endif; ?>
        </main>
    </div>

    <script>
        // Fungsi untuk menghasilkan angka acak sebagai CAPTCHA
        function generateCaptcha() {
            return Math.floor(Math.random() * 10000); // Angka acak 4 digit
        }

        // Event listener untuk link yang ada di konten
        document.querySelectorAll('.info-link').forEach(function(link) {
            link.addEventListener('click', function(event) {
                event.preventDefault(); // Mencegah link untuk dibuka langsung
                const linkUrl = this.href; // Ambil URL dari link yang diklik

                // Menghasilkan CAPTCHA
                const captcha = generateCaptcha();
                const userAnswer = prompt("Untuk melanjutkan, masukkan angka berikut: " + captcha);

                // Verifikasi jawaban pengguna
                if (userAnswer === String(captcha)) {
                    window.open(linkUrl, '_blank'); // Buka link di tab baru jika jawabannya benar
                } else {
                    alert("Jawaban salah! Anda tidak dapat membuka link.");
                }
            });
        });
    </script>
</body>
</html>
