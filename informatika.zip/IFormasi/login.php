<?php
session_start();
include('config.php');

$error = ''; // Inisialisasi variabel error agar tidak undefined

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $users = json_decode(file_get_contents(USERS_FILE), true); // Membaca data dari file JSON
    $username = $_POST['username'];
    $password = $_POST['password'];

    foreach ($users as $user) {
        if ($user['username'] === $username && password_verify($password, $user['password'])) {
            $_SESSION['user'] = $user;

            // Redirect berdasarkan role
            if ($user['role'] === 'admin') {
                header('Location: admin.php');
            } else {
                header('Location: dashboard_user.php');
            }
            exit;
        }
    }

    $error = 'Username atau password salah'; // Pesan error jika login gagal
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Iformasi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
        }
        .login-container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background: #ffffff;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        .btn-primary {
            width: 100%;
        }
        .error-message {
            color: #ff6f6f;
            background-color: #ffebeb;
            border: 1px solid #ffc2c2;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <header class="bg-primary text-white py-3">
        <div class="container text-center">
            <h1 class="m-0">Iformasi</h1>
        </div>
    </header>

    <main>
        <div class="login-container">
            <h2 class="text-center mb-4">Login ke Iformasi</h2>

            <!-- Pesan error jika login gagal -->
            <?php if ($error): ?>
                <div class="error-message">
                    <p class="mb-0"><?php echo $error; ?></p>
                </div>
            <?php endif; ?>

            <!-- Form login -->
            <form action="login.php" method="POST">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" id="username" name="username" class="form-control" required placeholder="Masukkan username">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" id="password" name="password" class="form-control" required placeholder="Masukkan password">
                </div>
                <button type="submit" class="btn btn-primary">Login</button>
            </form>

            <p class="text-center mt-4">
                Belum punya akun? <a href="register.php" class="text-primary">Daftar sekarang</a>
            </p>
        </div>
    </main>

    <footer class="bg-dark text-white text-center py-3 mt-5">
        <p class="m-0">&copy; 2024 Iformasi. Semua hak cipta dilindungi.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
