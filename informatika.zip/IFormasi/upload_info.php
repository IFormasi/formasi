<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'user') {
    header('Location: login.php'); // Redirect jika bukan user
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Menangani input form
    $judul = $_POST['judul'];
    $konten = $_POST['konten'];
    $image = null;

    // Menangani upload gambar
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $targetDir = "uploads/";
        $imageName = basename($_FILES['image']['name']);
        $targetFile = $targetDir . $imageName;

        // Pindahkan file gambar ke folder upload
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $image = $imageName; // Nama gambar yang diupload
        }
    }

    // Data informasi yang akan ditambahkan ke file JSON
    $informasiData = [
        'judul' => $judul,
        'konten' => $konten,
        'image' => $image,
        'user' => $_SESSION['user']['username'], // Username pengirim
        'created_at' => date('Y-m-d H:i:s')
    ];

    // Membaca data dari file JSON
    $informasiFile = 'informasi.json';
    $existingData = file_exists($informasiFile) ? json_decode(file_get_contents($informasiFile), true) : [];

    // Menambahkan data informasi baru ke dalam array
    $existingData[] = $informasiData;

    // Menyimpan data kembali ke file JSON
    file_put_contents($informasiFile, json_encode($existingData, JSON_PRETTY_PRINT));

    // Redirect ke halaman view_info setelah sukses upload
    header('Location: view_info.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Informasi - Iformasi</title>
    <link rel="stylesheet" href="assets/css/user.css"> <!-- Link ke CSS -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="header-container">
            <h1>Upload Informasi</h1>
        </div>
    </header>

    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <nav>
                <ul>
                    <li><a href="dashboard_user.php">Dashboard</a></li>
                    <li><a href="upload_info.php" class="active">Upload Informasi</a></li>
                    <li><a href="view_info.php">Lihat Informasi</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </aside>

        <main class="main-content">
            <h2>Upload Informasi</h2>
            <p>Silakan unggah informasi yang ingin Anda bagikan.</p>

            <!-- Form upload informasi -->
            <form action="upload_info.php" method="POST" enctype="multipart/form-data" class="upload-form">
                <!-- Input Judul Informasi -->
                <div class="input-group">
                    <label for="judul">Judul Informasi</label>
                    <input type="text" id="judul" name="judul" required placeholder="Masukkan judul informasi">
                </div>

                <!-- Input Konten Informasi -->
                <div class="input-group">
                    <label for="konten">Konten Informasi</label>
                    <textarea id="konten" name="konten" required placeholder="Masukkan konten informasi"></textarea>
                </div>

                <!-- Input Gambar -->
                <div class="input-group">
                    <label for="image">Pilih Gambar</label>
                    <input type="file" id="image" name="image" accept="image/*">
                </div>

                <!-- Tombol Submit -->
                <button type="submit" class="upload-btn">Upload</button>
            </form>
        </main>
    </div>
</body>
</html>
