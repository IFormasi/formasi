<?php
// Konfigurasi file JSON
define('USERS_FILE', 'users.json');
define('INFORMASI_FILE', 'informasi.json');

// Fungsi untuk membaca data dari JSON
function readJson($file) {
    return json_decode(file_get_contents($file), true);
}

// Fungsi untuk menulis data ke JSON
function writeJson($file, $data) {
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
}

// Fungsi untuk memeriksa role user
function isAdmin($user) {
    return isset($user['role']) && $user['role'] == 'admin';
}

// Fungsi untuk memeriksa apakah pengguna sudah login
function isLoggedIn() {
    return isset($_SESSION['user']);
}
?>
