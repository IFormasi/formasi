<?php
session_start();
include('config.php');

$success = ''; // Variabel untuk menyimpan pesan sukses
$error = '';   // Variabel untuk menyimpan pesan error

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $users = json_decode(file_get_contents(USERS_FILE), true); // Membaca data pengguna dari JSON
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Cek apakah username sudah terdaftar
    foreach ($users as $user) {
        if ($user['username'] === $username) {
            $error = 'Username sudah digunakan. Silakan pilih username lain.';
            break;
        }
    }

    // Jika tidak ada error, tambahkan pengguna baru
    if (!$error) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT); // Hash password
        $users[] = [
            'username' => $username,
            'password' => $hashedPassword,
            'role' => 'user' // Secara default, role adalah "user"
        ];
        file_put_contents(USERS_FILE, json_encode($users, JSON_PRETTY_PRINT)); // Simpan ke file JSON
        $success = 'Registrasi berhasil! Silakan login.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi - Iformasi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
        }
        .register-container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background: #ffffff;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        .btn-primary {
            width: 100%;
        }
        .success-message {
            color: #28a745;
            background-color: #e6f4ea;
            border: 1px solid #d1e7dd;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
        }
        .error-message {
            color: #dc3545;
            background-color: #f8d7da;
            border: 1px solid #f5c2c7;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <header class="bg-primary text-white py-3">
        <div class="container text-center">
            <h1 class="m-0">Iformasi</h1>
        </div>
    </header>

    <main>
        <div class="register-container">
            <h2 class="text-center mb-4">Daftar di Iformasi</h2>

            <!-- Menampilkan pesan sukses jika ada -->
            <?php if ($success): ?>
                <div class="success-message">
                    <p class="mb-0"><?php echo $success; ?></p>
                </div>
            <?php endif; ?>

            <!-- Menampilkan pesan error jika ada -->
            <?php if ($error): ?>
                <div class="error-message">
                    <p class="mb-0"><?php echo $error; ?></p>
                </div>
            <?php endif; ?>

            <!-- Form registrasi -->
            <form action="register.php" method="POST">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" id="username" name="username" class="form-control" required placeholder="Masukkan username">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" id="password" name="password" class="form-control" required placeholder="Masukkan password">
                </div>
                <button type="submit" class="btn btn-primary">Daftar</button>
            </form>

            <p class="text-center mt-4">
                Sudah punya akun? <a href="login.php" class="text-primary">Login sekarang</a>
            </p>
        </div>
    </main>

    <footer class="bg-dark text-white text-center py-3 mt-5">
        <p class="m-0">&copy; 2024 Iformasi. Semua hak cipta dilindungi.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
