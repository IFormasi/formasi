<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'user') {
    header('Location: login.php'); // Redirect jika bukan user
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard User - Iformasi</title>
    <link rel="stylesheet" href="assets/css/user.css"> <!-- Link ke CSS user -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="header-container">
            <h1>Dashboard User</h1>
        </div>
    </header>

    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <nav>
                <ul>
                    <li><a href="dashboard_user.php" class="active">Dashboard</a></li>
                    <li><a href="upload_info.php">Upload Informasi</a></li>
                    <li><a href="view_info.php">Lihat Informasi</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </aside>

        <!-- Konten Utama -->
        <main class="main-content">
            <h2>Selamat Datang, <?php echo htmlspecialchars($_SESSION['user']['username']); ?>!</h2>
            <p>Anda dapat mengunggah informasi atau melihat informasi yang telah tersedia.</p>
        </main>
    </div>
</body>
</html>
