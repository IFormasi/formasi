<?php
session_start();

// Cek apakah pengguna adalah admin
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: login.php'); // Redirect jika bukan admin
    exit;
}

// Membaca data dari file JSON
$informasiFile = 'informasi.json';
$existingData = file_exists($informasiFile) ? json_decode(file_get_contents($informasiFile), true) : [];

// Menghapus konten
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $deleteId = $_POST['delete_id'];

    // Hapus data dengan ID yang sesuai
    foreach ($existingData as $index => $informasi) {
        if ($informasi['created_at'] === $deleteId) { // Menggunakan created_at sebagai ID unik
            unset($existingData[$index]);
            break;
        }
    }

    // Menyimpan kembali data JSON setelah dihapus
    file_put_contents($informasiFile, json_encode(array_values($existingData), JSON_PRETTY_PRINT));

    // Redirect setelah penghapusan
    header('Location: manage_content.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Content - Iformasi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/user.css">
</head>
<body>
    <header class="bg-primary text-white py-3 fixed-top w-100">
        <div class="container">
            <h1 class="m-0">Manage Content</h1>
        </div>
    </header>

    <div class="dashboard-container mt-5 pt-5">
        <!-- Sidebar -->
        <aside class="sidebar bg-dark text-white p-4">
            <nav>
                <ul class="list-unstyled">
                    <li><a href="admin.php" class="text-white">Dashboard</a></li>
                    <li><a href="manage_content.php" class="text-white active">Manage Content</a></li>
                    <li><a href="logout.php" class="text-white">Logout</a></li>
                </ul>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content container py-5">
            <h2>Manage Content</h2>
            <p>Berikut adalah daftar informasi yang telah diunggah oleh pengguna. Anda dapat menghapus konten yang tidak sesuai.</p>

            <!-- Daftar informasi -->
            <?php if (empty($existingData)): ?>
                <p>Tidak ada informasi yang tersedia.</p>
            <?php else: ?>
                <?php foreach ($existingData as $informasi): ?>
                    <div class="card mb-4">
                        <div class="card-header">
                            <strong><?php echo htmlspecialchars($informasi['judul']); ?></strong>
                        </div>
                        <div class="card-body">
                            <p><strong>Konten:</strong></p>
                            <p><?php echo nl2br(htmlspecialchars($informasi['konten'])); ?></p>

                            <?php if ($informasi['image']): ?>
                                <p><strong>Gambar:</strong></p>
                                <img src="uploads/<?php echo htmlspecialchars($informasi['image']); ?>" class="img-fluid" alt="Gambar Informasi">
                            <?php endif; ?>

                            <p><strong>Pengirim:</strong> <?php echo htmlspecialchars($informasi['user']); ?></p>
                            <p><strong>Dikirim pada:</strong> <?php echo htmlspecialchars($informasi['created_at']); ?></p>

                            <!-- Tombol Hapus -->
                            <form action="manage_content.php" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus konten ini?')">
                                <input type="hidden" name="delete_id" value="<?php echo htmlspecialchars($informasi['created_at']); ?>">
                                <button type="submit" class="btn btn-danger">Hapus Konten</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </main>
    </div>

    <!-- Bootstrap JS dan Popper -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
