<?php
// Membaca data informasi dari file JSON
$informasiFile = 'informasi.json';
$existingData = file_exists($informasiFile) ? json_decode(file_get_contents($informasiFile), true) : [];

// Fungsi untuk memotong teks
function potongTeks($teks, $maksKarakter = 10) {
    return (strlen($teks) > $maksKarakter) ? substr($teks, 0, $maksKarakter) . '...' : $teks;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda - Iformasi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }

        header {
            background: linear-gradient(45deg, #007bff, #00c6ff);
            color: white;
        }

        .logo {
            font-size: 1.8rem;
            font-weight: bold;
        }

        .register-section {
            background-color: #f8f9fa;
            padding: 30px;
            border-radius: 10px;
        }

        .card {
            height: 100%;
            border: none;
            transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
        }

        .btn-view-all {
            background-color: #007bff;
            color: white;
            border-radius: 20px;
        }

        footer {
            background-color: #343a40;
            color: white;
        }

        .card-footer {
            background-color: transparent;
        }

        /* Responsif */
        @media (max-width: 768px) {
            .register-section h2 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <header class="py-3 shadow-sm">
        <div class="container d-flex justify-content-between align-items-center">
            <h1 class="logo">Iformasi</h1>
            <nav>
                <ul class="nav">
                    <li class="nav-item"><a class="nav-link text-white" href="index.php">Beranda</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="login.php">Login</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="register.php">Daftar</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="view_info.php">Lihat Informasi</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <div class="container py-5">
            <section class="register-section text-center mb-5 shadow-sm">
                <h2>Selamat Datang di Iformasi!</h2>
                <p class="text-muted">Silakan login atau daftar untuk mengakses fitur-fitur lainnya.</p>
            </section>

            <!-- Menampilkan informasi terbaru -->
            <section class="latest-info">
                <h3 class="text-center mb-4">Informasi Terbaru</h3>
                <?php if (empty($existingData)): ?>
                    <div class="alert alert-info text-center">Tidak ada informasi terbaru.</div>
                <?php else: ?>
                    <div class="row row-cols-1 row-cols-md-3 g-4">
                        <?php foreach ($existingData as $informasi): ?>
                            <div class="col">
                                <div class="card shadow-sm">
                                    <?php if (!empty($informasi['image'])): ?>
                                        <img src="uploads/<?php echo htmlspecialchars($informasi['image']); ?>" class="card-img-top" alt="Gambar Informasi">
                                    <?php endif; ?>
                                    <div class="card-body">
                                        <h5 class="card-title text-primary"><?php echo htmlspecialchars($informasi['judul']); ?></h5>
                                        <p class="card-text">
                                            <?php echo nl2br(htmlspecialchars(potongTeks($informasi['konten']))); ?>
                                        </p>
                                        <?php if (strlen($informasi['konten']) > 10): ?>
                                            <a href="view_info.php" class="btn btn-sm btn-view-all mt-2">View All</a>
                                        <?php endif; ?>
                                    </div>
                                    <div class="card-footer text-muted small">
                                        Pengirim: <?php echo htmlspecialchars($informasi['user']); ?> | 
                                        Tanggal: <?php echo htmlspecialchars($informasi['created_at']); ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>
        </div>
    </main>

    <footer class="py-3 text-center">
        <p>&copy; 2024 Iformasi. Semua hak cipta dilindungi.</p>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
